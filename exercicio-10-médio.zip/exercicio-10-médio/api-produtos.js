const express = require('express');
const app = express();
const PORT = 3002;

app.use(express.json());

let produtos = [
    { id: 1, nome: 'Bolo de Laranja', preco: 25.90, categoria: 'Bolos' },
    { id: 2, nome: 'Pão de Queijo', preco: 2.0, categoria: 'Pães' }
];
//GET- LISTAR
app.get('/produtos', (req, res) => {
    res.json(produtos);
});
//GET-BUSCAR PRODUTO POR ID
app.get('/produtos/:id',(req,res)=>{
    const id =parseInt(req.params.id) ;
    const produto = produtos.find(p => p.id === id);

    if(produto){
        res.json(produto);
    }else{
        res.status(404).json({erro: 'Produto não encontrado'});
    }
});
//POST- CRIAR PRODUTO
app.post('/produtos', (req,res)=>{
      const { nome, preco, categoria } = req.body ;
    
    // TODO: Validação básica
    if (!nome || !preco || !categoria) {
        return res.status(400).json({ erro: 'Dados incompletos' });
    }
    
    const novoProduto = {
         id: 3, nome: 'Bolo de Chocolate', preco: 29.90, categoria: 'Bolos' 
    };
    
    // TODO: Adicione ao array
    produtos.push(novoProduto);
    res.status(201).json(novoProduto);
});
//PUT- ATUALIZAR PRODUTO
app.put('/produtos/:id', (req, res) => {
    const id = parseInt(req.params.id) ;
    const index = produtos.findIndex( p => p.id === id );
    
    if (index === -1) {
        return res.status(404).json({ erro: 'Produto não encontrado' });
    }
    
    // TODO: Atualize o produto
    produtos[index] = { ...produtos[index], ...req.body };
    res.json(produtos[index]);
});
//DELETE- REMOVER PRODUTO
app.delete('/produtos/:id', (req,res)=> {
    const id = parseInt(req.params.id);
    const index = produtos.findIndex(p => p.id ===id);

    if (index === -1){
        return res.status(404).json({erro: 'Produto não encontrado'});
    }
    //Remova o produto
    produtos.splice(index,1);
    res.status(204).send();
});

app.listen(PORT,()=>{
    console.log(`API rodando em http://localhost:${PORT}`);
});