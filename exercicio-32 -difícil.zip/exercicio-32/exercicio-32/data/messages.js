// Dados em memória para mensagens
let messages = [
    {
        id: 1,
        title: 'Bem-vindo ao sistema',
        content: 'Esta é uma mensagem de boas-vindas para novos usuários.',
        userId: 1,
        priority: 'normal',
        read: true,
        createdAt: '2024-01-15T12:00:00.000Z',
        updatedAt: '2024-01-15T12:00:00.000Z',
        readAt: '2024-01-15T12:30:00.000Z'
    },
    {
        id: 2,
        title: 'Atualização do sistema',
        content: 'O sistema será atualizado na próxima semana. Prepare-se para algumas melhorias!',
        userId: 2,
        priority: 'high',
        read: false,
        createdAt: '2024-01-16T16:30:00.000Z',
        updatedAt: '2024-01-16T16:30:00.000Z',
        readAt: null
    },
    {
        id: 3,
        title: 'Lembrete de reunião',
        content: 'Não se esqueça da reunião de equipe amanhã às 14h.',
        userId: 1,
        priority: 'normal',
        read: true,
        createdAt: '2024-01-17T11:15:00.000Z',
        updatedAt: '2024-01-17T11:15:00.000Z',
        readAt: '2024-01-17T13:45:00.000Z'
    },
    {
        id: 4,
        title: 'Manutenção programada',
        content: 'Haverá manutenção no servidor no final de semana.',
        userId: 3,
        priority: 'low',
        read: false,
        createdAt: '2024-01-18T09:00:00.000Z',
        updatedAt: '2024-01-18T09:00:00.000Z',
        readAt: null
    }
];

// Contador para gerar IDs únicos
let nextMessageId = 5;

// Função para gerar próximo ID
function getNextMessageId() {
    return nextMessageId++;
}

// Função para encontrar mensagem por ID
function findMessageById(id) {
    return messages.find(message => message.id === parseInt(id));
}

// Função para encontrar mensagens por usuário
function findMessagesByUserId(userId) {
    return messages.filter(message => message.userId === parseInt(userId));
}

// Função para validar dados da mensagem
function validateMessageData(messageData) {
    const errors = [];

    if (!messageData.title || typeof messageData.title !== 'string' || messageData.title.trim().length < 3) {
        errors.push('Título é obrigatório e deve ter pelo menos 3 caracteres');
    }

    if (!messageData.content || typeof messageData.content !== 'string' || messageData.content.trim().length < 10) {
        errors.push('Conteúdo é obrigatório e deve ter pelo menos 10 caracteres');
    }

    if (!messageData.userId || typeof messageData.userId !== 'number') {
        errors.push('ID do usuário é obrigatório');
    }

    if (messageData.priority && !['low', 'normal', 'high', 'urgent'].includes(messageData.priority)) {
        errors.push('Prioridade deve ser: low, normal, high ou urgent');
    }

    if (messageData.read !== undefined && typeof messageData.read !== 'boolean') {
        errors.push('Read deve ser um valor booleano');
    }

    return errors;
}

// Função para criar nova mensagem
function createMessage(messageData) {
    const errors = validateMessageData(messageData);
    if (errors.length > 0) {
        throw new Error(errors.join(', '));
    }

    const newMessage = {
        id: getNextMessageId(),
        title: messageData.title.trim(),
        content: messageData.content.trim(),
        userId: messageData.userId,
        priority: messageData.priority || 'normal',
        read: messageData.read !== undefined ? messageData.read : false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        readAt: messageData.read ? new Date().toISOString() : null
    };

    messages.push(newMessage);
    return newMessage;
}

// Função para atualizar mensagem
function updateMessage(id, messageData) {
    const message = findMessageById(id);
    if (!message) {
        throw new Error('Mensagem não encontrada');
    }

    // Validar apenas os campos que estão sendo atualizados
    const updateData = {};
    if (messageData.title !== undefined) updateData.title = messageData.title;
    if (messageData.content !== undefined) updateData.content = messageData.content;
    if (messageData.priority !== undefined) updateData.priority = messageData.priority;
    if (messageData.read !== undefined) updateData.read = messageData.read;

    const errors = validateMessageData({ ...message, ...updateData });
    if (errors.length > 0) {
        throw new Error(errors.join(', '));
    }

    // Atualizar campos
    if (updateData.title) message.title = updateData.title.trim();
    if (updateData.content) message.content = updateData.content.trim();
    if (updateData.priority) message.priority = updateData.priority;
    if (updateData.read !== undefined) {
        message.read = updateData.read;
        if (updateData.read && !message.readAt) {
            message.readAt = new Date().toISOString();
        } else if (!updateData.read) {
            message.readAt = null;
        }
    }
    message.updatedAt = new Date().toISOString();

    return message;
}

// Função para marcar mensagem como lida
function markAsRead(id) {
    const message = findMessageById(id);
    if (!message) {
        throw new Error('Mensagem não encontrada');
    }

    if (!message.read) {
        message.read = true;
        message.readAt = new Date().toISOString();
        message.updatedAt = new Date().toISOString();
    }

    return message;
}

// Função para marcar mensagem como não lida
function markAsUnread(id) {
    const message = findMessageById(id);
    if (!message) {
        throw new Error('Mensagem não encontrada');
    }

    if (message.read) {
        message.read = false;
        message.readAt = null;
        message.updatedAt = new Date().toISOString();
    }

    return message;
}

// Função para deletar mensagem
function deleteMessage(id) {
    const messageIndex = messages.findIndex(message => message.id === parseInt(id));
    if (messageIndex === -1) {
        throw new Error('Mensagem não encontrada');
    }

    const deletedMessage = messages.splice(messageIndex, 1)[0];
    return deletedMessage;
}

// Função para obter estatísticas das mensagens
function getMessageStats() {
    return {
        total: messages.length,
        read: messages.filter(message => message.read).length,
        unread: messages.filter(message => !message.read).length,
        byPriority: {
            low: messages.filter(message => message.priority === 'low').length,
            normal: messages.filter(message => message.priority === 'normal').length,
            high: messages.filter(message => message.priority === 'high').length,
            urgent: messages.filter(message => message.priority === 'urgent').length
        }
    };
}

// Função para filtrar mensagens
function filterMessages(filters = {}) {
    let filteredMessages = [...messages];

    if (filters.userId) {
        filteredMessages = filteredMessages.filter(message => message.userId === parseInt(filters.userId));
    }

    if (filters.read !== undefined) {
        filteredMessages = filteredMessages.filter(message => message.read === (filters.read === 'true'));
    }

    if (filters.priority) {
        filteredMessages = filteredMessages.filter(message => message.priority === filters.priority);
    }

    if (filters.search) {
        const searchTerm = filters.search.toLowerCase();
        filteredMessages = filteredMessages.filter(message => 
            message.title.toLowerCase().includes(searchTerm) ||
            message.content.toLowerCase().includes(searchTerm)
        );
    }

    if (filters.dateFrom) {
        filteredMessages = filteredMessages.filter(message => 
            new Date(message.createdAt) >= new Date(filters.dateFrom)
        );
    }

    if (filters.dateTo) {
        filteredMessages = filteredMessages.filter(message => 
            new Date(message.createdAt) <= new Date(filters.dateTo)
        );
    }

    return filteredMessages;
}

// Função para ordenar mensagens
function sortMessages(messagesToSort, sortBy = 'createdAt', order = 'desc') {
    return messagesToSort.sort((a, b) => {
        let valueA = a[sortBy];
        let valueB = b[sortBy];

        if (sortBy.includes('At')) {
            valueA = new Date(valueA);
            valueB = new Date(valueB);
        }

        if (order === 'asc') {
            return valueA > valueB ? 1 : -1;
        } else {
            return valueA < valueB ? 1 : -1;
        }
    });
}

module.exports = {
    messages,
    getNextMessageId,
    findMessageById,
    findMessagesByUserId,
    validateMessageData,
    createMessage,
    updateMessage,
    markAsRead,
    markAsUnread,
    deleteMessage,
    getMessageStats,
    filterMessages,
    sortMessages
};