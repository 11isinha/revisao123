const express = require('express');
const router = express.Router();

// Importar dados
const { getUsers, getUserStats } = require('../data/users');
const { getFiles, getFileStats } = require('../data/files');
const { getMessages, getMessageStats } = require('../data/messages');

/**
 * GET /api/metrics
 * Retorna métricas básicas do sistema
 */
router.get('/', (req, res) => {
    try {
        // Obter estatísticas de usuários
        const userStats = getUserStats();
        
        // Obter estatísticas de arquivos
        const fileStats = getFileStats();
        
        // Obter estatísticas de mensagens
        const messageStats = getMessageStats();
        
        // Calcular métricas adicionais
        const users = getUsers();
        const files = getFiles();
        const messages = getMessages();
        
        // Usuários ativos (criados nos últimos 30 dias)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        const activeUsers = users.filter(user => 
            new Date(user.createdAt) >= thirtyDaysAgo
        ).length;
        
        // Arquivos recentes (últimos 7 dias)
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        const recentFiles = files.filter(file => 
            new Date(file.uploadedAt) >= sevenDaysAgo
        ).length;
        
        // Mensagens não lidas
        const unreadMessages = messages.filter(msg => !msg.read).length;
        
        // Distribuição de tipos de arquivo
        const fileTypeDistribution = {};
        files.forEach(file => {
            const type = file.mimetype.split('/')[0]; // image, text, application, etc.
            fileTypeDistribution[type] = (fileTypeDistribution[type] || 0) + 1;
        });
        
        // Distribuição de prioridades de mensagens
        const messagePriorityDistribution = {};
        messages.forEach(msg => {
            messagePriorityDistribution[msg.priority] = (messagePriorityDistribution[msg.priority] || 0) + 1;
        });
        
        // Métricas de sistema
        const systemMetrics = {
            timestamp: new Date().toISOString(),
            uptime: process.uptime(), // tempo de execução em segundos
            memoryUsage: process.memoryUsage(),
            nodeVersion: process.version,
            platform: process.platform
        };
        
        const metrics = {
            summary: {
                totalUsers: userStats.total,
                totalFiles: fileStats.total,
                totalMessages: messageStats.total,
                activeUsers,
                recentFiles,
                unreadMessages
            },
            users: {
                ...userStats,
                activeInLast30Days: activeUsers,
                averageAge: users.length > 0 ? 
                    Math.round(users.reduce((sum, user) => sum + user.age, 0) / users.length) : 0
            },
            files: {
                ...fileStats,
                recentInLast7Days: recentFiles,
                typeDistribution: fileTypeDistribution,
                averageSizeFormatted: formatFileSize(fileStats.averageSize || 0)
            },
            messages: {
                ...messageStats,
                unreadCount: unreadMessages,
                readCount: messages.length - unreadMessages,
                priorityDistribution: messagePriorityDistribution
            },
            system: systemMetrics
        };
        
        res.json({
            success: true,
            data: metrics,
            message: 'Métricas do sistema obtidas com sucesso'
        });
        
    } catch (error) {
        console.error('Erro ao obter métricas:', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor ao obter métricas',
            error: error.message
        });
    }
});

/**
 * GET /api/metrics/health
 * Verifica a saúde do sistema
 */
router.get('/health', (req, res) => {
    try {
        const health = {
            status: 'healthy',
            timestamp: new Date().toISOString(),
            uptime: process.uptime(),
            memory: {
                used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024), // MB
                total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024) // MB
            },
            services: {
                api: 'operational',
                database: 'operational' // simulado, já que usamos dados em memória
            }
        };
        
        res.json({
            success: true,
            data: health,
            message: 'Sistema operacional'
        });
        
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao verificar saúde do sistema',
            error: error.message
        });
    }
});

/**
 * GET /api/metrics/summary
 * Retorna apenas um resumo das métricas principais
 */
router.get('/summary', (req, res) => {
    try {
        const users = getUsers();
        const files = getFiles();
        const messages = getMessages();
        
        const summary = {
            totalUsers: users.length,
            totalFiles: files.length,
            totalMessages: messages.length,
            unreadMessages: messages.filter(msg => !msg.read).length,
            totalFileSize: formatFileSize(files.reduce((sum, file) => sum + file.size, 0)),
            lastActivity: new Date().toISOString()
        };
        
        res.json({
            success: true,
            data: summary,
            message: 'Resumo das métricas obtido com sucesso'
        });
        
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao obter resumo das métricas',
            error: error.message
        });
    }
});

// Função auxiliar para formatar tamanho de arquivo
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

module.exports = router;