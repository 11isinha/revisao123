const express = require('express');
const router = express.Router();

// Importar funções de dados das mensagens
const {
    messages,
    findMessageById,
    findMessagesByUserId,
    createMessage,
    updateMessage,
    markAsRead,
    markAsUnread,
    deleteMessage,
    getMessageStats,
    filterMessages,
    sortMessages
} = require('../data/messages');

// Importar função para verificar se usuário existe
const { findUserById } = require('../data/users');

// ===== ROTAS DE MENSAGENS =====

// GET /api/messages - Listar todas as mensagens
router.get('/', (req, res) => {
    try {
        const { 
            userId, 
            read, 
            priority, 
            search, 
            dateFrom, 
            dateTo, 
            sortBy = 'createdAt', 
            order = 'desc', 
            limit, 
            offset 
        } = req.query;
        
        // Aplicar filtros
        const filteredMessages = filterMessages({
            userId,
            read,
            priority,
            search,
            dateFrom,
            dateTo
        });

        // Ordenar resultados
        const sortedMessages = sortMessages(filteredMessages, sortBy, order);

        // Paginação
        const startIndex = offset ? parseInt(offset) : 0;
        const endIndex = limit ? startIndex + parseInt(limit) : sortedMessages.length;
        const paginatedMessages = sortedMessages.slice(startIndex, endIndex);

        // Adicionar informações do usuário para cada mensagem
        const messagesWithUserInfo = paginatedMessages.map(message => {
            const user = findUserById(message.userId);
            return {
                ...message,
                user: user ? {
                    id: user.id,
                    name: user.name,
                    email: user.email
                } : null
            };
        });

        res.json({
            success: true,
            data: messagesWithUserInfo,
            pagination: {
                total: filteredMessages.length,
                offset: startIndex,
                limit: limit ? parseInt(limit) : filteredMessages.length,
                hasMore: endIndex < filteredMessages.length
            },
            filters: {
                userId,
                read,
                priority,
                search,
                dateFrom,
                dateTo,
                sortBy,
                order
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao listar mensagens',
            error: error.message
        });
    }
});

// GET /api/messages/stats - Obter estatísticas das mensagens
router.get('/stats', (req, res) => {
    try {
        const stats = getMessageStats();
        
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao obter estatísticas',
            error: error.message
        });
    }
});

// GET /api/messages/user/:userId - Listar mensagens de um usuário específico
router.get('/user/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        const { read, priority, sortBy = 'createdAt', order = 'desc' } = req.query;
        
        // Verificar se usuário existe
        const user = findUserById(userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuário não encontrado',
                userId: parseInt(userId)
            });
        }

        let userMessages = findMessagesByUserId(userId);

        // Aplicar filtros adicionais
        if (read !== undefined) {
            const isRead = read === 'true';
            userMessages = userMessages.filter(message => message.read === isRead);
        }

        if (priority) {
            userMessages = userMessages.filter(message => message.priority === priority);
        }

        // Ordenar
        const sortedMessages = sortMessages(userMessages, sortBy, order);

        res.json({
            success: true,
            data: sortedMessages,
            user: {
                id: user.id,
                name: user.name,
                email: user.email
            },
            summary: {
                total: userMessages.length,
                read: userMessages.filter(msg => msg.read).length,
                unread: userMessages.filter(msg => !msg.read).length,
                byPriority: {
                    low: userMessages.filter(msg => msg.priority === 'low').length,
                    normal: userMessages.filter(msg => msg.priority === 'normal').length,
                    high: userMessages.filter(msg => msg.priority === 'high').length,
                    urgent: userMessages.filter(msg => msg.priority === 'urgent').length
                }
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar mensagens do usuário',
            error: error.message
        });
    }
});

// GET /api/messages/:id - Obter mensagem específica
router.get('/:id', (req, res) => {
    try {
        const { id } = req.params;
        const message = findMessageById(id);

        if (!message) {
            return res.status(404).json({
                success: false,
                message: 'Mensagem não encontrada',
                id: parseInt(id)
            });
        }

        // Buscar informações do usuário
        const user = findUserById(message.userId);

        res.json({
            success: true,
            data: {
                ...message,
                user: user ? {
                    id: user.id,
                    name: user.name,
                    email: user.email
                } : null
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar mensagem',
            error: error.message
        });
    }
});

// POST /api/messages - Criar nova mensagem
router.post('/', (req, res) => {
    try {
        const messageData = req.body;

        // Validação básica de entrada
        if (!messageData || Object.keys(messageData).length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Dados da mensagem são obrigatórios'
            });
        }

        // Verificar se usuário existe
        if (messageData.userId) {
            const user = findUserById(messageData.userId);
            if (!user) {
                return res.status(404).json({
                    success: false,
                    message: 'Usuário não encontrado',
                    userId: messageData.userId
                });
            }
        }

        const newMessage = createMessage(messageData);

        // Buscar informações do usuário para a resposta
        const user = findUserById(newMessage.userId);

        res.status(201).json({
            success: true,
            message: 'Mensagem criada com sucesso',
            data: {
                ...newMessage,
                user: user ? {
                    id: user.id,
                    name: user.name,
                    email: user.email
                } : null
            }
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: 'Erro ao criar mensagem',
            error: error.message
        });
    }
});

// PUT /api/messages/:id - Atualizar mensagem completa
router.put('/:id', (req, res) => {
    try {
        const { id } = req.params;
        const messageData = req.body;

        // Validação básica de entrada
        if (!messageData || Object.keys(messageData).length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Dados para atualização são obrigatórios'
            });
        }

        const updatedMessage = updateMessage(id, messageData);

        // Buscar informações do usuário
        const user = findUserById(updatedMessage.userId);

        res.json({
            success: true,
            message: 'Mensagem atualizada com sucesso',
            data: {
                ...updatedMessage,
                user: user ? {
                    id: user.id,
                    name: user.name,
                    email: user.email
                } : null
            }
        });
    } catch (error) {
        if (error.message === 'Mensagem não encontrada') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(400).json({
            success: false,
            message: 'Erro ao atualizar mensagem',
            error: error.message
        });
    }
});

// PATCH /api/messages/:id - Atualizar mensagem parcial
router.patch('/:id', (req, res) => {
    try {
        const { id } = req.params;
        const messageData = req.body;

        // Validação básica de entrada
        if (!messageData || Object.keys(messageData).length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Pelo menos um campo deve ser fornecido para atualização'
            });
        }

        const updatedMessage = updateMessage(id, messageData);

        // Buscar informações do usuário
        const user = findUserById(updatedMessage.userId);

        res.json({
            success: true,
            message: 'Mensagem atualizada parcialmente com sucesso',
            data: {
                ...updatedMessage,
                user: user ? {
                    id: user.id,
                    name: user.name,
                    email: user.email
                } : null
            }
        });
    } catch (error) {
        if (error.message === 'Mensagem não encontrada') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(400).json({
            success: false,
            message: 'Erro ao atualizar mensagem',
            error: error.message
        });
    }
});

// POST /api/messages/:id/read - Marcar mensagem como lida
router.post('/:id/read', (req, res) => {
    try {
        const { id } = req.params;
        const updatedMessage = markAsRead(id);

        // Buscar informações do usuário
        const user = findUserById(updatedMessage.userId);

        res.json({
            success: true,
            message: 'Mensagem marcada como lida',
            data: {
                ...updatedMessage,
                user: user ? {
                    id: user.id,
                    name: user.name,
                    email: user.email
                } : null
            }
        });
    } catch (error) {
        if (error.message === 'Mensagem não encontrada') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erro ao marcar mensagem como lida',
            error: error.message
        });
    }
});

// POST /api/messages/:id/unread - Marcar mensagem como não lida
router.post('/:id/unread', (req, res) => {
    try {
        const { id } = req.params;
        const updatedMessage = markAsUnread(id);

        // Buscar informações do usuário
        const user = findUserById(updatedMessage.userId);

        res.json({
            success: true,
            message: 'Mensagem marcada como não lida',
            data: {
                ...updatedMessage,
                user: user ? {
                    id: user.id,
                    name: user.name,
                    email: user.email
                } : null
            }
        });
    } catch (error) {
        if (error.message === 'Mensagem não encontrada') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erro ao marcar mensagem como não lida',
            error: error.message
        });
    }
});

// DELETE /api/messages/:id - Deletar mensagem
router.delete('/:id', (req, res) => {
    try {
        const { id } = req.params;
        const deletedMessage = deleteMessage(id);

        res.json({
            success: true,
            message: 'Mensagem deletada com sucesso',
            data: deletedMessage
        });
    } catch (error) {
        if (error.message === 'Mensagem não encontrada') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erro ao deletar mensagem',
            error: error.message
        });
    }
});

// GET /api/messages/priority/:priority - Listar mensagens por prioridade
router.get('/priority/:priority', (req, res) => {
    try {
        const { priority } = req.params;
        const { sortBy = 'createdAt', order = 'desc' } = req.query;

        // Validar prioridade
        if (!['low', 'normal', 'high', 'urgent'].includes(priority)) {
            return res.status(400).json({
                success: false,
                message: 'Prioridade inválida. Use: low, normal, high ou urgent',
                priority: priority
            });
        }

        const filteredMessages = filterMessages({ priority });
        const sortedMessages = sortMessages(filteredMessages, sortBy, order);

        // Adicionar informações do usuário
        const messagesWithUserInfo = sortedMessages.map(message => {
            const user = findUserById(message.userId);
            return {
                ...message,
                user: user ? {
                    id: user.id,
                    name: user.name,
                    email: user.email
                } : null
            };
        });

        res.json({
            success: true,
            data: messagesWithUserInfo,
            priority: priority,
            total: messagesWithUserInfo.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar mensagens por prioridade',
            error: error.message
        });
    }
});

// POST /api/messages/bulk-read - Marcar múltiplas mensagens como lidas
router.post('/bulk-read', (req, res) => {
    try {
        const { messageIds } = req.body;

        if (!messageIds || !Array.isArray(messageIds) || messageIds.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Lista de IDs de mensagens é obrigatória'
            });
        }

        const updatedMessages = [];
        const errors = [];

        messageIds.forEach(id => {
            try {
                const updatedMessage = markAsRead(id);
                updatedMessages.push(updatedMessage);
            } catch (error) {
                errors.push({
                    id: id,
                    error: error.message
                });
            }
        });

        res.json({
            success: true,
            message: `Operação concluída: ${updatedMessages.length} sucessos, ${errors.length} erros`,
            data: {
                updated: updatedMessages,
                errors: errors,
                summary: {
                    totalAttempted: messageIds.length,
                    successful: updatedMessages.length,
                    failed: errors.length
                }
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro na operação em lote',
            error: error.message
        });
    }
});

module.exports = router;