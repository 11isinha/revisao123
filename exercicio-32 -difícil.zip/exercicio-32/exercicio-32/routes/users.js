const express = require('express');
const router = express.Router();

// Importar funções de dados dos usuários
const {
    users,
    findUserById,
    findUserByEmail,
    createUser,
    updateUser,
    deleteUser,
    getUserStats
} = require('../data/users');

// ===== ROTAS DE USUÁRIOS =====

// GET /api/users - Listar todos os usuários
router.get('/', (req, res) => {
    try {
        const { active, search, sortBy = 'id', order = 'asc', limit, offset } = req.query;
        
        let filteredUsers = [...users];

        // Filtrar por status ativo
        if (active !== undefined) {
            const isActive = active === 'true';
            filteredUsers = filteredUsers.filter(user => user.active === isActive);
        }

        // Buscar por nome ou email
        if (search) {
            const searchTerm = search.toLowerCase();
            filteredUsers = filteredUsers.filter(user => 
                user.name.toLowerCase().includes(searchTerm) ||
                user.email.toLowerCase().includes(searchTerm)
            );
        }

        // Ordenar resultados
        filteredUsers.sort((a, b) => {
            let valueA = a[sortBy];
            let valueB = b[sortBy];

            if (typeof valueA === 'string') {
                valueA = valueA.toLowerCase();
                valueB = valueB.toLowerCase();
            }

            if (order === 'desc') {
                return valueA < valueB ? 1 : -1;
            } else {
                return valueA > valueB ? 1 : -1;
            }
        });

        // Paginação
        const startIndex = offset ? parseInt(offset) : 0;
        const endIndex = limit ? startIndex + parseInt(limit) : filteredUsers.length;
        const paginatedUsers = filteredUsers.slice(startIndex, endIndex);

        res.json({
            success: true,
            data: paginatedUsers,
            pagination: {
                total: filteredUsers.length,
                offset: startIndex,
                limit: limit ? parseInt(limit) : filteredUsers.length,
                hasMore: endIndex < filteredUsers.length
            },
            filters: {
                active,
                search,
                sortBy,
                order
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao listar usuários',
            error: error.message
        });
    }
});

// GET /api/users/stats - Obter estatísticas dos usuários
router.get('/stats', (req, res) => {
    try {
        const stats = getUserStats();
        
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao obter estatísticas',
            error: error.message
        });
    }
});

// GET /api/users/:id - Obter usuário específico
router.get('/:id', (req, res) => {
    try {
        const { id } = req.params;
        const user = findUserById(id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuário não encontrado',
                id: parseInt(id)
            });
        }

        res.json({
            success: true,
            data: user
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar usuário',
            error: error.message
        });
    }
});

// POST /api/users - Criar novo usuário
router.post('/', (req, res) => {
    try {
        const userData = req.body;

        // Validação básica de entrada
        if (!userData || Object.keys(userData).length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Dados do usuário são obrigatórios'
            });
        }

        const newUser = createUser(userData);

        res.status(201).json({
            success: true,
            message: 'Usuário criado com sucesso',
            data: newUser
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: 'Erro ao criar usuário',
            error: error.message
        });
    }
});

// PUT /api/users/:id - Atualizar usuário completo
router.put('/:id', (req, res) => {
    try {
        const { id } = req.params;
        const userData = req.body;

        // Validação básica de entrada
        if (!userData || Object.keys(userData).length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Dados para atualização são obrigatórios'
            });
        }

        const updatedUser = updateUser(id, userData);

        res.json({
            success: true,
            message: 'Usuário atualizado com sucesso',
            data: updatedUser
        });
    } catch (error) {
        if (error.message === 'Usuário não encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(400).json({
            success: false,
            message: 'Erro ao atualizar usuário',
            error: error.message
        });
    }
});

// PATCH /api/users/:id - Atualizar usuário parcial
router.patch('/:id', (req, res) => {
    try {
        const { id } = req.params;
        const userData = req.body;

        // Validação básica de entrada
        if (!userData || Object.keys(userData).length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Pelo menos um campo deve ser fornecido para atualização'
            });
        }

        const updatedUser = updateUser(id, userData);

        res.json({
            success: true,
            message: 'Usuário atualizado parcialmente com sucesso',
            data: updatedUser
        });
    } catch (error) {
        if (error.message === 'Usuário não encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(400).json({
            success: false,
            message: 'Erro ao atualizar usuário',
            error: error.message
        });
    }
});

// DELETE /api/users/:id - Deletar usuário
router.delete('/:id', (req, res) => {
    try {
        const { id } = req.params;
        const deletedUser = deleteUser(id);

        res.json({
            success: true,
            message: 'Usuário deletado com sucesso',
            data: deletedUser
        });
    } catch (error) {
        if (error.message === 'Usuário não encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erro ao deletar usuário',
            error: error.message
        });
    }
});

// POST /api/users/:id/activate - Ativar usuário
router.post('/:id/activate', (req, res) => {
    try {
        const { id } = req.params;
        const updatedUser = updateUser(id, { active: true });

        res.json({
            success: true,
            message: 'Usuário ativado com sucesso',
            data: updatedUser
        });
    } catch (error) {
        if (error.message === 'Usuário não encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erro ao ativar usuário',
            error: error.message
        });
    }
});

// POST /api/users/:id/deactivate - Desativar usuário
router.post('/:id/deactivate', (req, res) => {
    try {
        const { id } = req.params;
        const updatedUser = updateUser(id, { active: false });

        res.json({
            success: true,
            message: 'Usuário desativado com sucesso',
            data: updatedUser
        });
    } catch (error) {
        if (error.message === 'Usuário não encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erro ao desativar usuário',
            error: error.message
        });
    }
});

// GET /api/users/email/:email - Buscar usuário por email
router.get('/email/:email', (req, res) => {
    try {
        const { email } = req.params;
        const user = findUserByEmail(email);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuário não encontrado com este email',
                email: email
            });
        }

        res.json({
            success: true,
            data: user
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar usuário por email',
            error: error.message
        });
    }
});

module.exports = router;